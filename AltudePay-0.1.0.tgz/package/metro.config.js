const {getDefaultConfig, mergeConfig} = require('@react-native/metro-config');

/**
 * Metro configuration
 * https://reactnative.dev/docs/metro
 */
const defaultConfig = getDefaultConfig(__dirname);

const config = {
	resolver: {
		sourceExts: [...defaultConfig.resolver.sourceExts, 'mjs', 'cjs'],
	},
};

module.exports = mergeConfig(defaultConfig, config);
