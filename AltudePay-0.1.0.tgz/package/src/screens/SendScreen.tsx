import React, {useEffect, useState, useCallback} from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import Clipboard from '@react-native-clipboard/clipboard';
import {useNavigation, useRoute, RouteProp} from '@react-navigation/native';
import {BottomTabNavigationProp} from '@react-navigation/bottom-tabs';
import Svg, {Defs, LinearGradient, Rect, Stop} from 'react-native-svg';

import {usePayment} from '../hooks/usePayment';
import {getRecentRecipients, getUserPreferences} from '../services/storage';
import {isValidSolanaAddress, truncateAddress} from '../services/solana';
import {useWalletStore} from '../store/walletStore';
import {MainTabParamList, TransactionRecord} from '../types';
import {tokens} from '../theme/tokens';

type NavProp = BottomTabNavigationProp<MainTabParamList, 'Send'>;
type RoutePropType = RouteProp<MainTabParamList, 'Send'>;

export default function SendScreen(): React.JSX.Element {
  const route = useRoute<RoutePropType>();
  const navigation = useNavigation<NavProp>();

  const [recipient, setRecipient] = useState(route.params?.recipient ?? '');
  const [amount, setAmount] = useState(route.params?.amount ?? '0');
  const [memo, setMemo] = useState('');
  const [recentRecipients, setRecentRecipients] = useState<string[]>([]);

  const wallet = useWalletStore(s => s.wallet);
  const {mutate: sendPayment, isPending} = usePayment();

  useEffect(() => {
    getRecentRecipients().then(setRecentRecipients);
  }, []);

  const validate = useCallback((): string | null => {
    if (!wallet) {return 'No wallet ready. Go to Home to create one.';}
    if (!isValidSolanaAddress(recipient)) {return 'Enter a valid recipient wallet address.';}
    const amt = parseFloat(amount);
    if (isNaN(amt) || amt <= 0) {return 'Enter an amount greater than 0.';}
    if (recipient === wallet.publicKey) {return 'You cannot send to your own wallet.';}
    return null;
  }, [wallet, recipient, amount]);

  const handlePaymentSuccess = useCallback(
    async (record: TransactionRecord) => {
      setRecentRecipients(await getRecentRecipients());
      setRecipient('');
      setAmount('0');
      setMemo('');

      if (record.status === 'confirmed') {
        Alert.alert(
          'Payment confirmed',
          `The transaction was confirmed on Solana.\n\nSignature:\n${record.signature.slice(0, 20)}...`,
          [{text: 'OK', onPress: () => navigation.navigate('History')}],
        );
        return;
      }

      Alert.alert(
        'Payment submitted',
        `The transaction was broadcast successfully. Confirmation is still pending on Solana.\n\nSignature:\n${record.signature.slice(0, 20)}...`,
        [{text: 'OK', onPress: () => navigation.navigate('History')}],
      );
    },
    [navigation],
  );

  const handleKeypadTap = useCallback((value: string) => {
    setAmount(current => {
      if (value === 'back') {
        const next = current.slice(0, -1);
        return next.length === 0 ? '0' : next;
      }

      if (value === '.') {
        if (current.includes('.')) {return current;}
        return `${current}.`;
      }

      if (current === '0') {
        return value;
      }

      const [, decimals = ''] = current.split('.');
      if (decimals.length >= 6 && current.includes('.')) {
        return current;
      }

      return `${current}${value}`;
    });
  }, []);

  const handlePasteRecipient = useCallback(async () => {
    const text = (await Clipboard.getString()).trim();
    if (!text) {
      Alert.alert('Clipboard is empty', 'Copy a wallet address and try again.');
      return;
    }
    setRecipient(text);
  }, []);

  const amountDisplay = amount === '0' ? '$0' : `$${amount}`;

  const submitPayment = useCallback(
    (amt: number) => {
      sendPayment(
        {recipientAddress: recipient, amount: amt, memo: memo || undefined},
        {
          onSuccess: record => {
            handlePaymentSuccess(record).catch(() => {
              Alert.alert('Error', 'Payment succeeded, but the UI could not update.');
            });
          },
          onError: err => {
            Alert.alert('Payment Failed', (err as Error).message);
          },
        },
      );
    },
    [handlePaymentSuccess, memo, recipient, sendPayment],
  );

  const handleSend = useCallback(async () => {
    const error = validate();
    if (error) {
      Alert.alert('Validation Error', error);
      return;
    }

    const amt = parseFloat(amount);
    const preferences = await getUserPreferences();

    if (!preferences.confirmBeforeSending) {
      submitPayment(amt);
      return;
    }

    Alert.alert(
      'Confirm Payment',
      `Send ${amt} USDC to\n${recipient.slice(0, 8)}...${recipient.slice(-8)}?`,
      [
        {text: 'Cancel', style: 'cancel'},
        {
          text: 'Send',
          onPress: () => submitPayment(amt),
        },
      ],
    );
  }, [amount, recipient, submitPayment, validate]);

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <ScrollView
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled">
        <View style={styles.hero}>
          <Svg style={StyleSheet.absoluteFill} width="100%" height="100%">
            <Defs>
              <LinearGradient id="sendHeroGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <Stop offset="0%" stopColor="#3f8cff" />
                <Stop offset="55%" stopColor="#4f7ef4" />
                <Stop offset="100%" stopColor="#6d5ce8" />
              </LinearGradient>
            </Defs>
            <Rect x="0" y="0" width="100%" height="100%" fill="url(#sendHeroGradient)" />
          </Svg>

          <View style={styles.heroGlowTop} />
          <View style={styles.heroGlowBottom} />

          <Text style={styles.kicker}>SEND PAYMENT</Text>
          <Text style={styles.amount}>{amountDisplay}</Text>
          <Text style={styles.tokenLabel}>USDC stablecoin demo</Text>
        </View>

        <View style={styles.keypadWrap}>
          {[
            '1', '2', '3',
            '4', '5', '6',
            '7', '8', '9',
            '.', '0', 'back',
          ].map(key => (
            <TouchableOpacity
              key={key}
              style={styles.key}
              onPress={() => handleKeypadTap(key)}>
              <Text style={styles.keyText}>{key === 'back' ? '⌫' : key}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.form}>
          {recentRecipients.length > 0 ? (
            <>
              <Text style={styles.label}>Recent Recipients</Text>
              <View style={styles.recipientList}>
                {recentRecipients.map(address => (
                  <TouchableOpacity
                    key={address}
                    style={styles.recipientChip}
                    onPress={() => setRecipient(address)}>
                    <Text style={styles.recipientChipText}>
                      {truncateAddress(address, 4)}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </>
          ) : null}

          <View style={styles.rowHeader}>
            <Text style={styles.label}>Recipient Address</Text>
            <TouchableOpacity onPress={() => handlePasteRecipient()}>
              <Text style={styles.pasteText}>Paste</Text>
            </TouchableOpacity>
          </View>
          <TextInput
            style={styles.input}
            placeholder="Solana wallet address (Base58)"
            placeholderTextColor={tokens.colors.textMuted}
            value={recipient}
            onChangeText={setRecipient}
            autoCapitalize="none"
            autoCorrect={false}
            multiline
          />

          <Text style={styles.label}>Memo (optional)</Text>
          <TextInput
            style={styles.input}
            placeholder="Payment memo"
            placeholderTextColor={tokens.colors.textMuted}
            value={memo}
            onChangeText={setMemo}
            autoCorrect={false}
          />

          <View style={styles.secondaryActions}>
            <TouchableOpacity
              style={styles.secondaryActionBtn}
              onPress={() => Alert.alert('Request', 'Request flow is coming next.')}>
              <Text style={styles.secondaryActionText}>Request</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.secondaryActionBtn}
              onPress={() => navigation.navigate('QR')}>
              <Text style={styles.secondaryActionText}>Open Scanner</Text>
            </TouchableOpacity>
          </View>

          <TouchableOpacity
            style={[styles.sendBtn, isPending && styles.sendBtnDisabled]}
            onPress={() => {
              handleSend().catch(() => {
                Alert.alert('Error', 'Could not start the payment flow.');
              });
            }}
            disabled={isPending}>
            {isPending ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.sendBtnText}>Send Payment</Text>
            )}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: tokens.colors.page,
  },
  content: {
    paddingHorizontal: 20,
    paddingTop: 24,
    paddingBottom: 28,
  },
  hero: {
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 180,
    borderRadius: tokens.radius.lg,
    marginBottom: 14,
    overflow: 'hidden',
    position: 'relative',
  },
  heroGlowTop: {
    position: 'absolute',
    width: 150,
    height: 150,
    borderRadius: 999,
    top: -58,
    right: -34,
    backgroundColor: 'rgba(255,255,255,0.22)',
  },
  heroGlowBottom: {
    position: 'absolute',
    width: 110,
    height: 110,
    borderRadius: 999,
    bottom: -44,
    left: -20,
    backgroundColor: 'rgba(255,255,255,0.16)',
  },
  kicker: {
    color: 'rgba(255,255,255,0.92)',
    fontWeight: '800',
    letterSpacing: 1,
    fontSize: 11,
  },
  amount: {
    color: '#ffffff',
    fontSize: 62,
    fontWeight: '900',
    marginTop: 8,
  },
  tokenLabel: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 13,
  },
  keypadWrap: {
    marginTop: 6,
    marginBottom: 20,
    backgroundColor: tokens.colors.card,
    borderRadius: tokens.radius.lg,
    borderWidth: 1,
    borderColor: tokens.colors.border,
    paddingVertical: 12,
    paddingHorizontal: 8,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  key: {
    width: '31%',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    borderRadius: tokens.radius.md,
  },
  keyText: {
    color: tokens.colors.textPrimary,
    fontSize: 33,
    fontWeight: '500',
  },
  form: {
    gap: 4,
    backgroundColor: tokens.colors.card,
    borderRadius: tokens.radius.lg,
    borderWidth: 1,
    borderColor: tokens.colors.border,
    paddingHorizontal: 14,
    paddingBottom: 16,
    paddingTop: 6,
  },
  label: {
    color: tokens.colors.textPrimary,
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 6,
    marginTop: 12,
  },
  rowHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  pasteText: {
    color: tokens.colors.accent,
    fontWeight: '800',
    marginTop: 10,
    fontSize: 13,
  },
  recipientList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 4,
  },
  recipientChip: {
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: tokens.colors.border,
    backgroundColor: tokens.colors.card,
  },
  recipientChipText: {
    color: tokens.colors.textPrimary,
    fontSize: 12,
    fontFamily: 'monospace',
  },
  input: {
    backgroundColor: tokens.colors.card,
    borderWidth: 1,
    borderColor: tokens.colors.border,
    borderRadius: tokens.radius.md,
    paddingHorizontal: 16,
    paddingVertical: 14,
    color: tokens.colors.textPrimary,
    fontSize: 15,
  },
  secondaryActions: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 16,
  },
  secondaryActionBtn: {
    flex: 1,
    borderRadius: tokens.radius.pill,
    alignItems: 'center',
    paddingVertical: 14,
    backgroundColor: tokens.colors.accentSoft,
  },
  secondaryActionText: {
    color: tokens.colors.accentDark,
    fontSize: 16,
    fontWeight: '700',
  },
  sendBtn: {
    backgroundColor: tokens.colors.accent,
    borderRadius: tokens.radius.md,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 14,
  },
  sendBtnDisabled: {
    opacity: 0.6,
  },
  sendBtnText: {
    color: '#ffffff',
    fontWeight: '800',
    fontSize: 20,
  },
});
