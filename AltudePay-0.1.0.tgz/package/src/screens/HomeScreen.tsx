import React, {useCallback} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  Alert,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import {BottomTabNavigationProp} from '@react-navigation/bottom-tabs';
import Svg, {Defs, LinearGradient, Rect, Stop} from 'react-native-svg';

import {useBalance} from '../hooks/useBalance';
import {useWalletStore} from '../store/walletStore';
import {generateDemoWallet, truncateAddress} from '../services/solana';
import BalanceCard from '../components/BalanceCard';
import WalletAddress from '../components/WalletAddress';
import {MainTabParamList} from '../types';
import {tokens} from '../theme/tokens';

type NavProp = BottomTabNavigationProp<MainTabParamList, 'Home'>;

export default function HomeScreen(): React.JSX.Element {
  const navigation = useNavigation<NavProp>();
  const wallet = useWalletStore(s => s.wallet);
  const setWallet = useWalletStore(s => s.setWallet);
  const removeWallet = useWalletStore(s => s.removeWallet);

  const {data: balance, isLoading, refetch} = useBalance();

  const hasWallet = typeof wallet?.publicKey === 'string' && wallet.publicKey.length > 0;

  const displayAddress = hasWallet ? truncateAddress(wallet!.publicKey, 6) : 'No wallet';

  const handleGenerateWallet = useCallback(async () => {
    Alert.alert(
      hasWallet ? 'Replace Wallet' : 'Generate Demo Wallet',
      hasWallet
        ? 'This will replace the wallet currently stored on this device. Make sure you have your private key backed up.'
        : 'Create a new wallet on this device. Your private key stays local and never leaves the phone.',
      [
        {text: 'Cancel', style: 'cancel'},
        {
          text: hasWallet ? 'Replace' : 'Generate',
          style: hasWallet ? 'destructive' : 'default',
          onPress: async () => {
            const newWallet = await generateDemoWallet();
            await setWallet(newWallet);
          },
        },
      ],
    );
  }, [hasWallet, setWallet]);

  const handleDisconnectWallet = useCallback(() => {
    Alert.alert(
      'Disconnect Wallet',
      'Remove the wallet stored on this device?',
      [
        {text: 'Cancel', style: 'cancel'},
        {
          text: 'Disconnect',
          style: 'destructive',
          onPress: async () => {
            await removeWallet();
          },
        },
      ],
    );
  }, [removeWallet]);

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      refreshControl={
        <RefreshControl
          refreshing={isLoading}
          onRefresh={refetch}
          tintColor={tokens.colors.accent}
        />
      }>
      <View style={styles.hero}>
        <Svg style={StyleSheet.absoluteFill} width="100%" height="100%">
          <Defs>
            <LinearGradient id="homeHeroGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <Stop offset="0%" stopColor="#3f8cff" />
              <Stop offset="55%" stopColor="#4f7ef4" />
              <Stop offset="100%" stopColor="#6d5ce8" />
            </LinearGradient>
          </Defs>
          <Rect x="0" y="0" width="100%" height="100%" fill="url(#homeHeroGradient)" />
        </Svg>

        <View style={styles.heroGlowTop} />
        <View style={styles.heroGlowBottom} />

        <View style={styles.heroHeaderRow}>
          <Text style={styles.kicker}>WELCOME BACK</Text>
          {hasWallet ? (
            <TouchableOpacity
              onPress={handleDisconnectWallet}
              style={styles.heroSecondaryAction}>
              <Text style={styles.heroSecondaryActionText}>Disconnect</Text>
            </TouchableOpacity>
          ) : null}
        </View>

        <Text style={styles.heroTitle}>{displayAddress}</Text>
        <Text style={styles.heroSubtitle}>Manage payments and monitor wallet activity from one place.</Text>
      </View>

      {hasWallet ? (
        <>
          <WalletAddress address={wallet!.publicKey} />

          <BalanceCard
            solBalance={balance?.solBalance ?? 0}
            usdcBalance={balance?.usdcBalance ?? 0}
            isLoading={isLoading}
          />

          <View style={styles.actions}>
            <TouchableOpacity
              style={[styles.actionBtn, styles.primaryBtn]}
              onPress={() => navigation.navigate('Send')}>
              <Text style={styles.actionBtnText}>Make a Payment</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.actionBtn, styles.secondaryBtn]}
              onPress={() => navigation.navigate('QR')}>
              <Text style={styles.actionBtnTextSecondary}>Receive QR</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.actionBtn, styles.ghostBtn]}
              onPress={handleGenerateWallet}>
              <Text style={styles.ghostBtnText}>Generate New Wallet</Text>
            </TouchableOpacity>
          </View>
        </>
      ) : (
        <View style={styles.noWallet}>
          <Text style={styles.noWalletText}>No wallet ready yet</Text>
          <Text style={styles.noWalletSubtext}>
            Create a wallet to start sending and receiving payments.
          </Text>
          <TouchableOpacity
            style={[styles.actionBtn, styles.primaryBtn]}
            onPress={handleGenerateWallet}>
            <Text style={styles.actionBtnText}>Create Wallet</Text>
          </TouchableOpacity>
        </View>
      )}

      <View style={styles.badge}>
        <Text style={styles.badgeText}>TEST NETWORK</Text>
      </View>

      <View style={styles.footerNote}>
        <Text style={styles.footerNoteText}>USDC payments enabled on the test network</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: tokens.colors.page,
  },
  content: {
    paddingHorizontal: 20,
    paddingTop: 28,
    paddingBottom: 32,
  },
  hero: {
    minHeight: 176,
    borderRadius: tokens.radius.lg,
    paddingHorizontal: 18,
    paddingTop: 18,
    paddingBottom: 20,
    marginBottom: 24,
    overflow: 'hidden',
    position: 'relative',
  },
  heroGlowTop: {
    position: 'absolute',
    width: 160,
    height: 160,
    borderRadius: 999,
    top: -66,
    right: -30,
    backgroundColor: 'rgba(255,255,255,0.24)',
  },
  heroGlowBottom: {
    position: 'absolute',
    width: 120,
    height: 120,
    borderRadius: 999,
    bottom: -48,
    left: -26,
    backgroundColor: 'rgba(255,255,255,0.18)',
  },
  heroHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
    gap: 10,
  },
  kicker: {
    color: 'rgba(255,255,255,0.92)',
    fontWeight: '800',
    letterSpacing: 1,
    fontSize: 11,
  },
  heroTitle: {
    color: '#ffffff',
    fontSize: 30,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  heroSubtitle: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 14,
    marginTop: 8,
    lineHeight: 20,
  },
  heroSecondaryAction: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: tokens.radius.pill,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.45)',
    backgroundColor: 'rgba(255,255,255,0.16)',
  },
  heroSecondaryActionText: {
    color: '#ffffff',
    fontSize: 13,
    fontWeight: '700',
  },
  actions: {
    marginTop: 24,
    gap: 12,
  },
  actionBtn: {
    borderRadius: tokens.radius.md,
    paddingVertical: 16,
    alignItems: 'center',
  },
  primaryBtn: {
    backgroundColor: tokens.colors.accent,
  },
  secondaryBtn: {
    borderWidth: 1,
    borderColor: tokens.colors.accent,
    backgroundColor: '#fff',
  },
  ghostBtn: {
    borderWidth: 1,
    borderColor: tokens.colors.border,
    backgroundColor: tokens.colors.card,
  },
  actionBtnText: {
    color: '#fff',
    fontWeight: '800',
    fontSize: 16,
  },
  actionBtnTextSecondary: {
    color: tokens.colors.accent,
    fontWeight: '800',
    fontSize: 16,
  },
  ghostBtnText: {
    color: tokens.colors.textPrimary,
    fontWeight: '600',
    fontSize: 15,
  },
  noWallet: {
    alignItems: 'center',
    paddingVertical: 40,
    gap: 14,
    backgroundColor: tokens.colors.card,
    borderRadius: tokens.radius.lg,
    borderWidth: 1,
    borderColor: tokens.colors.border,
    paddingHorizontal: 16,
  },
  noWalletText: {
    color: tokens.colors.textPrimary,
    fontSize: 20,
    fontWeight: '700',
  },
  noWalletSubtext: {
    color: tokens.colors.textMuted,
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 8,
  },
  badge: {
    marginTop: 40,
    alignSelf: 'center',
    backgroundColor: tokens.colors.card,
    paddingHorizontal: 14,
    paddingVertical: 4,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: tokens.colors.success,
  },
  badgeText: {
    color: tokens.colors.success,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1,
  },
  footerNote: {
    marginTop: 12,
    alignItems: 'center',
  },
  footerNoteText: {
    color: tokens.colors.textMuted,
    fontSize: 12,
  },
});
