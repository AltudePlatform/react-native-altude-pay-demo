import React from 'react';
import {View, Text, StyleSheet, ActivityIndicator} from 'react-native';
import {tokens} from '../theme/tokens';

interface Props {
  solBalance: number;
  usdcBalance: number;
  isLoading: boolean;
}

export default function BalanceCard({
  solBalance,
  usdcBalance,
  isLoading,
}: Props): React.JSX.Element {
  if (isLoading) {
    return (
      <View style={[styles.card, styles.loadingCard]}>
        <ActivityIndicator color={tokens.colors.accent} />
      </View>
    );
  }

  return (
    <View style={styles.card}>
      <Text style={styles.cardTitle}>Portfolio</Text>

      <View style={styles.row}>
        <View style={styles.balanceItem}>
          <Text style={styles.balanceLabel}>USDC</Text>
          <Text style={styles.balanceValue}>
            {usdcBalance.toLocaleString('en-US', {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })}
          </Text>
          <Text style={styles.balanceCurrency}>USDC</Text>
        </View>

        <View style={styles.divider} />

        <View style={styles.balanceItem}>
          <Text style={styles.balanceLabel}>SOL</Text>
          <Text style={styles.balanceValue}>
            {solBalance.toLocaleString('en-US', {
              minimumFractionDigits: 4,
              maximumFractionDigits: 4,
            })}
          </Text>
          <Text style={styles.balanceCurrency}>SOL</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: tokens.colors.card,
    borderRadius: 20,
    padding: 24,
    borderWidth: 1,
    borderColor: tokens.colors.border,
  },
  loadingCard: {
    height: 120,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardTitle: {
    color: tokens.colors.textMuted,
    fontSize: 12,
    fontWeight: '600',
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 16,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  balanceItem: {
    alignItems: 'center',
    flex: 1,
  },
  balanceLabel: {
    color: tokens.colors.textMuted,
    fontSize: 12,
    marginBottom: 4,
  },
  balanceValue: {
    color: tokens.colors.textPrimary,
    fontSize: 26,
    fontWeight: '700',
    fontFamily: 'monospace',
  },
  balanceCurrency: {
    color: tokens.colors.accent,
    fontSize: 12,
    fontWeight: '600',
    marginTop: 2,
  },
  divider: {
    width: 1,
    height: 50,
    backgroundColor: tokens.colors.border,
  },
});
