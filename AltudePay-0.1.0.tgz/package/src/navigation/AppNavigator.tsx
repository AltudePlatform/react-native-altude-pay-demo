import React from 'react';
import {Text, StyleSheet, View} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {createNativeStackNavigator} from '@react-navigation/native-stack';

import {MainTabParamList, UserProfile} from '../types';
import HomeScreen from '../screens/HomeScreen';
import SendScreen from '../screens/SendScreen';
import HistoryScreen from '../screens/HistoryScreen';
import QRScreen from '../screens/QRScreen';
import OnboardingScreen from '../screens/OnboardingScreen';
import {tokens} from '../theme/tokens';

const Tab = createBottomTabNavigator<MainTabParamList>();
const RootStack = createNativeStackNavigator<RootStackParamList>();

type RootStackParamList = {
  Onboarding: undefined;
  MainTabs: undefined;
};

type AppNavigatorProps = {
  onboardingComplete: boolean;
  onOnboardingComplete: (profile: UserProfile) => Promise<void>;
};

function tabIcon(shape: 'circle' | 'diamond' | 'bars' | 'square') {
  return ({focused}: {focused: boolean}) => (
    <View style={[styles.iconBase, focused ? styles.iconFocused : styles.iconMuted]}>
      {shape === 'circle' ? <View style={styles.iconCircle} /> : null}
      {shape === 'diamond' ? <View style={styles.iconDiamond} /> : null}
      {shape === 'bars' ? (
        <View style={styles.iconBarsWrap}>
          <View style={styles.iconBarShort} />
          <View style={styles.iconBarLong} />
        </View>
      ) : null}
      {shape === 'square' ? <View style={styles.iconSquare} /> : null}
    </View>
  );
}

function MainTabs(): React.JSX.Element {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: tokens.colors.accent,
        tabBarInactiveTintColor: tokens.colors.textMuted,
        tabBarStyle: {
          backgroundColor: tokens.colors.tabBg,
          borderTopColor: tokens.colors.border,
          height: 66,
          paddingBottom: 8,
          paddingTop: 6,
        },
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: '700',
        },
      }}>
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{title: 'Dashboard', tabBarIcon: tabIcon('circle')}}
      />
      <Tab.Screen
        name="Send"
        component={SendScreen}
        options={{title: 'Pay', tabBarIcon: tabIcon('diamond')}}
      />
      <Tab.Screen
        name="History"
        component={HistoryScreen}
        options={{title: 'Activity', tabBarIcon: tabIcon('bars')}}
      />
      <Tab.Screen
        name="QR"
        component={QRScreen}
        options={{title: 'Receive', tabBarIcon: tabIcon('square')}}
      />
    </Tab.Navigator>
  );
}

export default function AppNavigator({
  onboardingComplete,
  onOnboardingComplete,
}: AppNavigatorProps): React.JSX.Element {
  return (
    <NavigationContainer>
      <RootStack.Navigator screenOptions={{headerShown: false}}>
        {!onboardingComplete ? (
          <RootStack.Screen name="Onboarding">
            {() => <OnboardingScreen onComplete={onOnboardingComplete} />}
          </RootStack.Screen>
        ) : null}
        <RootStack.Screen name="MainTabs" component={MainTabs} />
      </RootStack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  iconBase: {
    width: 22,
    height: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconFocused: {
    opacity: 1,
  },
  iconMuted: {
    opacity: 0.5,
  },
  iconCircle: {
    width: 12,
    height: 12,
    borderRadius: 999,
    borderWidth: 2,
    borderColor: tokens.colors.accent,
  },
  iconDiamond: {
    width: 11,
    height: 11,
    borderWidth: 2,
    borderColor: tokens.colors.accent,
    transform: [{rotate: '45deg'}],
  },
  iconBarsWrap: {
    gap: 3,
  },
  iconBarShort: {
    width: 10,
    height: 2,
    backgroundColor: tokens.colors.accent,
    borderRadius: 2,
  },
  iconBarLong: {
    width: 14,
    height: 2,
    backgroundColor: tokens.colors.accent,
    borderRadius: 2,
  },
  iconSquare: {
    width: 11,
    height: 11,
    borderWidth: 2,
    borderColor: tokens.colors.accent,
    borderRadius: 3,
  },
});
