/**
 * AltudePay – Solana USDC Payment Demo
 *
 * Entry point. Hydrates persisted client state on startup,
 * then delegates to the navigation tree.
 */
import React, {useEffect, useState} from 'react';
import {SafeAreaProvider} from 'react-native-safe-area-context';
import {QueryClient, QueryClientProvider} from '@tanstack/react-query';
import {StatusBar, View, ActivityIndicator, StyleSheet} from 'react-native';

import AppNavigator from './src/navigation/AppNavigator';
import {
  ensureClientState,
  getWallet,
  hasCompletedOnboarding,
  saveUserProfile,
} from './src/services/storage';
import {useWalletStore} from './src/store/walletStore';
import {UserProfile} from './src/types';
import {tokens} from './src/theme/tokens';
import {ensureMinimumSolBalance, generateDemoWallet} from './src/services/solana';

function withTimeout<T>(
  promise: Promise<T>,
  timeoutMs: number,
  errorMessage: string,
): Promise<T> {
  return new Promise((resolve, reject) => {
    const timeoutId = setTimeout(() => {
      reject(new Error(errorMessage));
    }, timeoutMs);

    promise.then(
      value => {
        clearTimeout(timeoutId);
        resolve(value);
      },
      error => {
        clearTimeout(timeoutId);
        reject(error);
      },
    );
  });
}

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 2,
      staleTime: 10_000,
    },
  },
});

function AppContent(): React.JSX.Element {
  const hydrateWallet = useWalletStore(s => s.hydrate);
  const setWallet = useWalletStore(s => s.setWallet);
  const [ready, setReady] = useState(false);
  const [onboardingComplete, setOnboardingComplete] = useState(false);

  useEffect(() => {
    let cancelled = false;

    (async () => {
      try {
        await ensureClientState();
        const [storedWallet, completed] = await Promise.all([
          getWallet(),
          hasCompletedOnboarding(),
        ]);

        const wallet =
          storedWallet ??
          (await withTimeout(
            generateDemoWallet(),
            12_000,
            'Wallet generation timed out',
          ));
        if (!storedWallet) {
          try {
            await setWallet(wallet);
          } catch {
            // If persistence fails, still continue with the in-memory wallet.
          }
        }

        if (!cancelled) {
          hydrateWallet(wallet);
          setOnboardingComplete(completed);
        }

        // Keep startup responsive; airdrop runs in the background for credits.
        ensureMinimumSolBalance(wallet.publicKey, 5).catch(() => {
          // Ignore faucet/rate-limit failures so app startup flow still works.
        });
      } catch {
        if (!cancelled) {
          hydrateWallet(null);
          setOnboardingComplete(false);
        }
      } finally {
        if (!cancelled) {
          setReady(true);
        }
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [hydrateWallet, setWallet]);

  const handleOnboardingComplete = async (profile: UserProfile) => {
    await saveUserProfile(profile);
    setOnboardingComplete(true);
  };

  if (!ready) {
    return (
      <View style={styles.loadingScreen}>
        <ActivityIndicator color={tokens.colors.accent} size="large" />
      </View>
    );
  }

  return (
    <>
      <StatusBar
        barStyle="dark-content"
        backgroundColor={tokens.colors.page}
      />
      <AppNavigator
        onboardingComplete={onboardingComplete}
        onOnboardingComplete={handleOnboardingComplete}
      />
    </>
  );
}

export default function App(): React.JSX.Element {
  return (
    <QueryClientProvider client={queryClient}>
      <SafeAreaProvider>
        <AppContent />
      </SafeAreaProvider>
    </QueryClientProvider>
  );
}

const styles = StyleSheet.create({
  loadingScreen: {
    flex: 1,
    backgroundColor: tokens.colors.page,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
